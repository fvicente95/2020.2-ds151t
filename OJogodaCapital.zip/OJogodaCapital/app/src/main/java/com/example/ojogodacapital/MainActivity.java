package com.example.ojogodacapital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String[] estado = {
            "Sao Paulo",
            "Parana",
            "Santa Catarina",
            "Rio Grande do Sul",
            "Rio de Janeiro",
            "Amazonas",
            "Minas Gerais",
            "Espirito Santo",
            "Bahia",
            "Goias",
            "Acre",
            "Para",
            "Pernambuco",
            "Paraiba",
            "Roraima"
    };

    Random r = new Random();
    int num;
    int trie=0;
    int cont=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num = r.nextInt(15);
        TextView out = findViewById(R.id.textView);
        out.setText(estado[num]);
    }

    public  void onResposta(View view) {
        String[] capital = {
                "Sao Paulo",
                "Curitiba",
                "Florianopolis",
                "Porto Alegre",
                "Rio de Janeiro",
                "Manaus",
                "Belo Horizonte",
                "Vitória",
                "Salvador",
                "Goiania",
                "Rio Branco",
                "Belem",
                "Recife",
                "Joao Pessoa",
                "Boa Vista"
        };

        EditText inputCapital = findViewById(R.id.editTextTextPersonName);
        String inputCapitalTxt = inputCapital.getText().toString();

        if (inputCapitalTxt.equals(capital[num])) {
            TextView out = findViewById(R.id.textView2);
            out.setText("Acertou!!!");
            trie++;
        } else {
            TextView out = findViewById(R.id.textView2);
            out.setText("Errou!!!");
        }

        TextView outPonto = findViewById(R.id.textView3);
        String trieS = Integer.toString(trie);
        outPonto.setText(trieS);

        cont++;
        if (cont == 5){
            Button btnResposta = findViewById(R.id.button);
            btnResposta.setEnabled(false);

            Button btnProximo = findViewById(R.id.button2);
            btnProximo.setEnabled(false);
        }

        Button btnResposta = findViewById(R.id.button);
        btnResposta.setEnabled(false);

    }

    public void onProximo(View view){
        num = r.nextInt(15);
        TextView out = findViewById(R.id.textView);
        out.setText(estado[num]);

        EditText inputCapital = findViewById(R.id.editTextTextPersonName);
        inputCapital.setText("");

        TextView outErrou = findViewById(R.id.textView2);
        outErrou.setText("");

        Button btnResposta = findViewById(R.id.button);
        btnResposta.setEnabled(true);


    }
}